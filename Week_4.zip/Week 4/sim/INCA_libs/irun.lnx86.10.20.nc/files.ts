1671658020 /home/buet/cds.lib
1671658025 /home/buet/hdl.var
1674849356 /home/buet/Desktop/Week 4/test/alu_top_tb.sv
1674804196 /mnt/hgfs/Ulka/Week 4/rtl/alu.v
1675412914 /mnt/hgfs/Ulka/Week 4/rtl/alu_controller.v
1675416630 /mnt/hgfs/Ulka/Week 4/rtl/alu_top.v
1674804088 /mnt/hgfs/Ulka/Week 4/rtl/comparator.v
1674804112 /mnt/hgfs/Ulka/Week 4/rtl/counter.v
1674804126 /mnt/hgfs/Ulka/Week 4/rtl/posedge_detector.v
1674804136 /mnt/hgfs/Ulka/Week 4/rtl/shift_reg.v
1675412932 /mnt/hgfs/Ulka/Week 4/rtl/spi_controller.v
1675415341 /mnt/hgfs/Ulka/Week 4/rtl/spi_slave.v
1674806426 /mnt/hgfs/Ulka/Week 4/test/alu_top_tb.sv
